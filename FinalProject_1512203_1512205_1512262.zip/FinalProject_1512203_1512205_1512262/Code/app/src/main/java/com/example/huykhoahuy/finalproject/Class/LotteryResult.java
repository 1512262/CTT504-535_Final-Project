package com.example.huykhoahuy.finalproject.Class;

import java.util.ArrayList;

public class LotteryResult {
    private ArrayList<String> ListResults;

    public ArrayList<String> getListResults() {
        return ListResults;
    }

    public void setListResults(ArrayList<String> listResults) {
        ListResults = listResults;
    }
}
